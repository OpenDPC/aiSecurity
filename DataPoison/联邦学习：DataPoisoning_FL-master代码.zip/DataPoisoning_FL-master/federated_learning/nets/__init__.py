from .cifar_10_cnn import Cifar10CNN
from .fashion_mnist_cnn import FashionMNISTCNN
