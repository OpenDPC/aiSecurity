import copy
import math

import random
import numpy as np
import torch

from aggregation import krum
from settings import NUM_CLIENTS, MAX_MALICIOUS_NODES, malicious_nodes

n = NUM_CLIENTS
m = MAX_MALICIOUS_NODES


def cal_distance(t1, t2):
    t1 = np.array(t1)
    t2 = np.array(t2)
    return np.sqrt(sum((t1 - t2) ** 2))


def trimmed_mean_attack(honest_clients_params):
    honest_clients_params = copy.deepcopy(honest_clients_params)
    malicious_params = copy.deepcopy(honest_clients_params[0])
    for key in honest_clients_params[0].keys():
        shape = honest_clients_params[0][key].shape
        flattened_layer_params = []

        for i in range(len(honest_clients_params)):
            flattened_layer_params.append(np.array(honest_clients_params[i][key].view(-1)))

        flattened_layer_params = np.array(flattened_layer_params)
        trimmed_mean_attack_layer = []
        for i in range(len(flattened_layer_params[0])):
            col_max = 0
            for j in range(len(flattened_layer_params)):
                col_max = max(flattened_layer_params[j, i], col_max)
            if 0 > col_max:
                trimmed_mean_attack_layer.append(random.uniform(col_max, col_max / 2))
            else:
                trimmed_mean_attack_layer.append(random.uniform(col_max, 2 * col_max))
        malicious_params[key] = torch.tensor(trimmed_mean_attack_layer).view(shape)

    return malicious_params


def krum_attack(honest_clients_params, global_model):
    client_params = copy.deepcopy(honest_clients_params)
    honest_clients_params = copy.deepcopy(honest_clients_params)
    global_params = global_model.state_dict()
    d = sum([param.nelement() for param in global_model.parameters()])
    scores = []
    distance_re = 0
    g = []
    for key in global_params.keys():
        g += global_params[key].view(-1)

    for i in range(len(honest_clients_params)):
        score = 0
        distances = []
        t1 = []
        for key in honest_clients_params[i].keys():
            t1 += honest_clients_params[i][key].view(-1)

        # 当前模型和全局模型的距离
        distance_re = max(distance_re, cal_distance(t1, g))

        # 非恶意节点模型间的距离
        for j in range(len(honest_clients_params)):
            if i == j:
                continue
            t2 = []
            for key in honest_clients_params[j].keys():
                t2 += honest_clients_params[j][key].view(-1)
            t1 = np.array(t1)
            t2 = np.array(t2)
            distances.append(sum((t1 - t2) ** 2))
        distances.sort()

        for k in range(n - m - 1):
            score += distances[k]
        scores.append(score)

    scores.sort()

    # 构造恶意模型，让krum每次都选择到恶意模型
    a = math.sqrt(1 / ((n - 2 * m - 1) * d) * scores[0]) + 1 / math.sqrt(d) * distance_re

    malicious_params = None
    while a > 1e-5:
        print(a)
        malicious_params = copy.deepcopy(global_params)
        for key in malicious_params.keys():
            shape = global_params[key].shape
            flattened_layer_params = np.array(global_params[key].view(-1)) - a
            malicious_params[key] = torch.tensor(flattened_layer_params).view(shape)

        for i in range(len(malicious_nodes)):
            client_params.append(malicious_params)

        selected_params, selected_idx = krum(client_params)
        if selected_idx in malicious_nodes:
            return selected_params
        client_params = client_params[:-3]
        a /= 2

    return malicious_params
