import math
import os
import random
import time

import torch
import numpy as np
import logging.config
from tqdm import tqdm

import aggregation
import attack
from model import CNN

from dataset import load_dataset
import copy

from settings import NUM_CLIENTS, malicious_nodes

NUM_EPOCHS = 5
LOCAL_ITERS = 1
BATCH_SIZE = 5
DATASET = "fashion_mnist"
# DATASET = "mnist"
DEVICE = torch.device("cpu")
print('Device:', DEVICE)

lr = 0.001


def train(local_model, device, dataset, iters):
    local_model.to(device)
    criterion = torch.nn.CrossEntropyLoss().to(device)
    optimizer = torch.optim.Adam(local_model.parameters(), lr=lr)
    train_loss = 0.0
    local_model.train()

    for i in range(iters):
        batch_loss = 0.0
        for batch_idx, (data, target) in tqdm(enumerate(dataset), total=len(dataset)):
            data, target = data.to(device), target.to(device)
            optimizer.zero_grad()
            output = local_model(data)

            loss = criterion(output, target)
            batch_loss += loss.item() * data.size(0)
            loss.backward()
            optimizer.step()

        train_loss += batch_loss / len(dataset)
    return local_model, train_loss / iters


def test(model, dataloader):
    criterion = torch.nn.CrossEntropyLoss()
    test_loss = 0.0
    correct = 0
    model.eval()
    for batch_idx, (data, target) in tqdm(enumerate(dataloader), total=len(dataloader.dataset) / BATCH_SIZE):
        output = model(data)
        loss = criterion(output, target)
        test_loss += loss.item() * data.size(0)
        preds = output.argmax(dim=1, keepdim=True)
        correct += preds.eq(target.view_as(preds)).sum().item()
    accuracy = correct / len(dataloader.dataset)

    return test_loss / len(dataloader.dataset), accuracy


if __name__ == "__main__":
    if not os.path.isdir('models'):
        os.mkdir('models')
    if not os.path.isdir('results'):
        os.mkdir('results')

    timestamp = time.strftime("%Y%m%d%H%M%S", time.localtime())
    log_name = ('results/' + timestamp + '_federated_' + DATASET + "_" + str(NUM_EPOCHS) + "_" + str(
        NUM_CLIENTS) + "_" + str(LOCAL_ITERS))

    logging.basicConfig(filename=log_name, level=logging.DEBUG)
    logger = logging.getLogger()

    train_data, validation_data, test_data = load_dataset(batch_size=BATCH_SIZE, dataset=DATASET)

    # 数据划分到不同client
    train_distributed_dataset = [[] for _ in range(NUM_CLIENTS)]
    for batch_idx, (data, target) in enumerate(train_data):
        train_distributed_dataset[batch_idx % NUM_CLIENTS].append((data, target))

    best_model = None
    global_model = CNN()
    global_params = global_model.state_dict()

    global_model.train()
    all_train_loss = list()
    all_val_loss = list()
    val_loss_min = np.Inf

    for epoch in range(1, NUM_EPOCHS + 1):
        print("\nEpoch :", str(epoch))
        local_params, local_losses = [], []

        for idx in range(NUM_CLIENTS):
            if idx in malicious_nodes:
                continue
            model, loss = train(copy.deepcopy(global_model), DEVICE, train_distributed_dataset[idx], LOCAL_ITERS)
            local_losses.append(copy.deepcopy(loss))
            local_params.append(copy.deepcopy(model.state_dict()))
            _, accuracy = test(model, test_data)
            logger.info('Client {}: Test accuracy {:.8f} '.format(idx, accuracy))
            print('Client {}: Test accuracy {:.8f} '.format(idx, accuracy))
        malicious_params = attack.krum_attack(local_params, global_model)

        for i in range(len(malicious_nodes)):
            local_params.append(malicious_params)

        global_params = aggregation.mix_aggregation(local_params, epoch)
        global_model.load_state_dict(global_params)
        all_train_loss.append(sum(local_losses) / len(local_losses))

        val_loss, accuracy = test(global_model, validation_data)
        all_val_loss.append(val_loss)
        print('Epoch: {}/{}, Train Loss: {:.8f}, Val Loss: {:.8f}, Val Accuracy: {:.8f}'
              .format(epoch, NUM_EPOCHS, all_train_loss[-1], val_loss, accuracy))
        logger.info('Epoch: {}/{}, Train Loss: {:.8f}, Val Loss: {:.8f}, Val Accuracy: {:.8f}'
                    .format(epoch, NUM_EPOCHS, all_train_loss[-1], val_loss, accuracy))

        if val_loss < val_loss_min:
            val_loss_min = val_loss
            best_model = copy.deepcopy(global_model)
        #    logger.info("Saving Model State")
        #    torch.save(global_model.state_dict(), "models/" + DATASET + "_" + str(NUM_CLIENTS) + "_federated.sav")

    test_loss, accuracy = test(best_model, test_data)
    logger.info('Best global test accuracy {:.8f}'.format(accuracy))
    print('Best global test accuracy {:.8f}'.format(accuracy))
