import copy
import math
import time

import numpy as np
import torch

from settings import NUM_CLIENTS, MAX_MALICIOUS_NODES

n = NUM_CLIENTS
m = MAX_MALICIOUS_NODES


def cal_distance(t1, t2):
    t1 = np.array(t1)
    t2 = np.array(t2)
    return np.sqrt(sum((t1 - t2) ** 2))


def multi_krum(client_params, select_num=1):
    client_params = copy.deepcopy(client_params)
    scores = []
    selected_clients = []
    for i in range(len(client_params)):
        score = 0
        distances = []
        t1 = []
        for key in client_params[i].keys():
            t1 += client_params[i][key].view(-1)
        for j in range(len(client_params)):
            if i == j:
                continue
            t2 = []
            for key in client_params[j].keys():
                t2 += client_params[j][key].view(-1)
            # 计算模型i和模型j的欧氏距离
            distances.append(cal_distance(t1, t2))
        distances.sort()
        # 选择与当前模型最相似的n-m-2个模型
        for k in range(n - m - 1):
            score += distances[k]
        scores.append((i, score))

    # 按分数排序
    scores.sort(key=lambda x: x[1])

    for i, t in enumerate(scores):
        # t: (client_idx, score)
        print("Client{} selected".format(t[0]))
        selected_clients.append(client_params[t[0]])
        if len(selected_clients) == select_num:
            break
    return selected_clients


def krum(client_params):
    client_params = copy.deepcopy(client_params)
    scores = []
    for i in range(len(client_params)):
        score = 0
        distances = []
        t1 = []
        for key in client_params[i].keys():
            t1 += client_params[i][key].view(-1)
        for j in range(len(client_params)):
            if i == j:
                continue
            t2 = []
            for key in client_params[j].keys():
                t2 += client_params[j][key].view(-1)
            # 计算模型i和模型j的欧氏距离
            distances.append(cal_distance(t1, t2))
        distances.sort()
        # 选择与当前模型最相似的n-m-2个模型
        for k in range(n-m-1):
            score += distances[k]
        scores.append((i, score))

    # 按分数排序
    scores.sort(key=lambda x: x[1])
    print("Client{} selected".format(scores[0][0]))
    return client_params[scores[0][0]], scores[0][0]


def trimmed_mean(client_params):
    client_params = copy.deepcopy(client_params)
    trimmed_params = copy.deepcopy(client_params[0])

    for key in client_params[0].keys():
        # 保存原来的shape再展平
        shape = client_params[0][key].shape
        flattened_layer_params = []

        for i in range(len(client_params)):
            flattened_layer_params.append(np.array(client_params[i][key].view(-1)))
        flattened_layer_params = np.array(flattened_layer_params)

        trimmed_layer_params = []
        # 按列求平均
        for i in range(len(flattened_layer_params[0])):
            t = []
            for j in range(len(flattened_layer_params)):
                t.append(flattened_layer_params[j, i])
            t.sort()
            if len(flattened_layer_params) > n - m:
                trimmed_layer_params.append(np.mean(t[math.ceil(m / 2):-math.ceil(m / 2)]))
            else:
                trimmed_layer_params.append(np.mean(t))

        trimmed_params[key] = torch.tensor(trimmed_layer_params).view(shape)
    return trimmed_params


def bulyan(client_params):
    selected_clients = multi_krum(client_params, NUM_CLIENTS - 2 * MAX_MALICIOUS_NODES)
    return trimmed_mean(selected_clients)


def mix_aggregation(client_params, current_iter):
    timestamp = time.strftime("%Y%m%d%H%M%S", time.localtime())
    flag = int(timestamp) % 3
    if current_iter == 1 or flag == 0:
        print("Trimmed mean selected")
        return trimmed_mean(client_params)
    elif flag == 1:
        print("Krum selected")
        return krum(client_params)[0]
    else:
        print("Bulyan selected")
        return bulyan(client_params)


def FedAvg(params):

    global_params = copy.deepcopy(params[0])
    for key in global_params.keys():
        for param in params[1:]:
            global_params[key] += param[key]
        global_params[key] = torch.div(global_params[key], len(params))
    return global_params
