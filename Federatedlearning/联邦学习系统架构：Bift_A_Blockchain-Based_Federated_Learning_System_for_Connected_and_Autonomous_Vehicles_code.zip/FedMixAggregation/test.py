import copy
import math
import random
import time

import numpy as np
import torch

from model import CNN


def test():
    return 1, 2


if __name__ == '__main__':
    a, b = test()
    print(a)
    print(b)
    # model = CNN()
    # param = model.state_dict()
    # for key in param.keys():
    #     param[key].view(-1)
    #     # print(key + " " + str(param[key].shape))
    # for key in param.keys():
    #     print(key + " " + str(param[key].shape))
    # trimmed_params = trimmed_mean([param, param, param])
    # for key in trimmed_params.keys():
    #     print(key + " " + str(trimmed_params[key].shape))
