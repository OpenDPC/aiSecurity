NUM_CLIENTS = 10
MAX_MALICIOUS_NODES = 3
malicious_nodes = [7, 8, 9]
